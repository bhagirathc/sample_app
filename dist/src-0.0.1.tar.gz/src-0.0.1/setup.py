from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Case study project for Oracle Blr",
    author="BVR",
    packages=find_packages(),
    license="MIT"
)